function togglePartNames() {
       if (showPartName==true) {
    showPartName=false;
} else if (showPartName==false) {
    showPartName=true;
}
readCoins();
}
