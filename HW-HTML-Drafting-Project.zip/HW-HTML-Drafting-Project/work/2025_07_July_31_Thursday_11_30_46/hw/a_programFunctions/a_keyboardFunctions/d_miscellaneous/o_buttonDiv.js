function buttonDiv() {
if (coinFocus!=null) {
if (coinFocus.lastElementChild.firstElementChild.style.display=="none") {
coinFocus.lastElementChild.firstElementChild.style.display="block";
} else {
coinFocus.lastElementChild.firstElementChild.style.display="none";
}
}
}
