function recoverCoinFocus() {
if (utilityLayer0.children.length > 0) {
coinFocus  = utilityLayer0.firstElementChild;
} else {
curFocus = 0;
}
}