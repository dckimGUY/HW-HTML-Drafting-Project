function toggleInterfaceShelf() {
if (interfaceShelf.style.display=="none") {

interfaceShelf.style.display="block";

} else {

interfaceShelf.style.display="none";

}
}
