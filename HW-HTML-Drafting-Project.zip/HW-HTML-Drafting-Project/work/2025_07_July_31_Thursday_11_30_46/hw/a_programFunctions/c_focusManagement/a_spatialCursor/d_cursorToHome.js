function cursorToHome() {
Cur.style.top     =   0 + "px";
Cur.style.left    =   document.documentElement.scrollLeft;
Cur.dataset.top   =   0 + "px";
Cur.dataset.left  =   document.documentElement.scrollLeft;
}
