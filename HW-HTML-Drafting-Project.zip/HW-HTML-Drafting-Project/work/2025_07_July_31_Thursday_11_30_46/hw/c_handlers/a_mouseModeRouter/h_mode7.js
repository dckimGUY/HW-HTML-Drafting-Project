let mode7 = {};
mode7.mousemove  = function(event,ctrl,shift) { };
mode7.mousedown  = function(event,ctrl,shift) { };
mode7.mouseup    = function(event,ctrl,shift) { };
mode7.mouseclick = function(event,ctrl,shift) { };
mode7.dblclick   = function(event,ctrl,shift) { };