z_wizardCode.z_wizard = {};
z_wizardCode.z_wizard.a_documentation = `

`;
z_wizardCode.z_wizard.b_code = `
Oops! I guess I haven't gotten around to this one yet. Don't worry, I'm working on it!
`;
