function duplicateTuner() {

/*    -    */ if (kC == 109 && cC ==  45) { lessG(); }
/*    +    */ if (kC == 107 && cC ==  43) { moreG(); }

if (coinFocus!=null) {

const scaleFactor = parseFloat(coinFocus.dataset.scale);



/*    /    */ if (kC == 111 && cC ==  47) { }
/*    *    */ if (kC == 106 && cC ==  42) { }


/*    7    */ if (kC == 103 && cC ==  55) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + "px";
coinFocus.dataset.left = window.scrollX + "px";
coinFocus.style.top    = window.scrollY + "px";
coinFocus.dataset.top  = window.scrollY + "px";
} else {
Cur.style.left   = window.scrollX + "px";
Cur.dataset.left = window.scrollX + "px";
Cur.style.top    = window.scrollY + "px";
Cur.dataset.top  = window.scrollY + "px";
}
}
/*    8    */ if (kC == 104 && cC ==  56) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ;
coinFocus.dataset.left = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ; 
coinFocus.style.top    = window.scrollY + "px";
coinFocus.dataset.top  = window.scrollY + "px";
} else {
Cur.style.left   = window.scrollX + (window.innerWidth/2) + "px";
Cur.dataset.left = window.scrollX + (window.innerWidth/2) + "px"; 
Cur.style.top    = window.scrollY + "px";
Cur.dataset.top  = window.scrollY + "px";
}
}
/*    9    */ if (kC == 105 && cC ==  57) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px" ;
coinFocus.dataset.left = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px" ; 
coinFocus.style.top    = window.scrollY + "px";
coinFocus.dataset.top  = window.scrollY + "px";
} else {
Cur.style.left   = window.scrollX + window.innerWidth + "px" ;
Cur.dataset.left = window.scrollX + window.innerWidth + "px" ; 
Cur.style.top    = window.scrollY + "px";
Cur.dataset.top  = window.scrollY + "px";
}
}
/*    4    */ if (kC == 100 && cC ==  52) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + "px";
coinFocus.dataset.left = window.scrollX + "px";
coinFocus.style.top    = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
coinFocus.dataset.top  = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
} else {
Cur.style.left   = window.scrollX + "px";
Cur.dataset.left = window.scrollX + "px";
Cur.style.top    = window.scrollY + (window.innerHeight/2) + "px";
Cur.dataset.top  = window.scrollY + (window.innerHeight/2) + "px";
}
}
/*    5    */ if (kC == 101 && cC ==  53) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ;
coinFocus.dataset.left = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ; 
coinFocus.style.top    = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
coinFocus.dataset.top  = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
} else {
Cur.style.left   = window.scrollX + (window.innerWidth/2) + "px";
Cur.dataset.left = window.scrollX + (window.innerWidth/2) + "px"; 
Cur.style.top    = window.scrollY + (window.innerHeight/2) + "px";
Cur.dataset.top  = window.scrollY + (window.innerHeight/2) + "px";
}
}
/*    6    */ if (kC == 102 && cC ==  54) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px";
coinFocus.dataset.left = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px"; 
coinFocus.style.top    = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
coinFocus.dataset.top  = window.scrollY + (window.innerHeight/2) - parseInt(coinFocus.style.height)*scaleFactor/2 + "px";
} else {
Cur.style.left   = window.scrollX + window.innerWidth + "px";
Cur.dataset.left = window.scrollX + window.innerWidth + "px"; 
Cur.style.top    = window.scrollY + (window.innerHeight/2) + "px";
Cur.dataset.top  = window.scrollY + (window.innerHeight/2) + "px";
}
}
/*    1    */ if (kC ==  97 && cC ==  49) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + "px";
coinFocus.dataset.left = window.scrollX + "px"; 
coinFocus.style.top    = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
coinFocus.dataset.top  = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
} else {
Cur.style.left   = window.scrollX + "px";
Cur.dataset.left = window.scrollX + "px"; 
Cur.style.top    = window.scrollY + window.innerHeight + "px";
Cur.dataset.top  = window.scrollY + window.innerHeight + "px";
}
}
/*    2    */ if (kC ==  98 && cC ==  50) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ;
coinFocus.dataset.left = window.scrollX + (window.innerWidth/2)  - parseInt(coinFocus.style.width)*scaleFactor/2 + "px" ; 
coinFocus.style.top    = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
coinFocus.dataset.top  = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
} else {
Cur.style.left   = window.scrollX + (window.innerWidth/2) + "px";
Cur.dataset.left = window.scrollX + (window.innerWidth/2) + "px"; 
Cur.style.top    = window.scrollY + window.innerHeight + "px";
Cur.dataset.top  = window.scrollY + window.innerHeight + "px";
}
}
/*    3    */ if (kC ==  99 && cC ==  51) {
if (curFocus==0) {
coinFocus.style.left   = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px" ;
coinFocus.dataset.left = window.scrollX + window.innerWidth  - parseInt(coinFocus.style.width)*scaleFactor + "px" ; 
coinFocus.style.top    = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
coinFocus.dataset.top  = window.scrollY + window.innerHeight - parseInt(coinFocus.style.height)*scaleFactor + "px";
} else {
Cur.style.left   = window.scrollX + window.innerWidth + "px";
Cur.dataset.left = window.scrollX + window.innerWidth + "px"; 
Cur.style.top    = window.scrollY + window.innerHeight + "px";
Cur.dataset.top  = window.scrollY + window.innerHeight + "px";
}
}

/*    0    */ if (kC ==  96 && cC ==  48) { }
/*    .    */ if (kC == 110 && cC ==  46) { }







}














}