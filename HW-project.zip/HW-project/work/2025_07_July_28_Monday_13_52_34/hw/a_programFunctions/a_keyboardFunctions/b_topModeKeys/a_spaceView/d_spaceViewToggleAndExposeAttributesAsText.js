function spaceViewToggleAndExposeAttributesAsText(keyInfo) {
if (spaceView==false) {
spaceViewOn(keyInfo);
} else if (spaceView==true) {
spaceViewOff(keyInfo);
}
}
