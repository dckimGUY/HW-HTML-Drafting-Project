function lowerTripartiteZ() {
if (coinFocus!=null) {
       if (coinFocus.dataset.coinTrip==Ts0) {
if (parseInt(coinFocus.style.zIndex) > findZextrema().lowestSel0Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) - internalStep - 1; }
} else if (coinFocus.dataset.coinTrip==Ts1) {
if (parseInt(coinFocus.style.zIndex) > findZextrema().lowestSel1Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) - internalStep - 1; }
} else if (coinFocus.dataset.coinTrip==Ts2) {
if (parseInt(coinFocus.style.zIndex) > findZextrema().lowestSel2Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) - internalStep - 1; }
}
}
manageTripartiteZ();
}
