let mode3 = {};
mode3.mousemove  = function(event,ctrl,shift,M) { };
mode3.mousedown  = function(event,ctrl,shift,M) { };
mode3.mouseup    = function(event,ctrl,shift,M) { };
mode3.mouseclick = function(event,ctrl,shift,M) { };
mode3.dblclick   = function(event,ctrl,shift,M) { };
