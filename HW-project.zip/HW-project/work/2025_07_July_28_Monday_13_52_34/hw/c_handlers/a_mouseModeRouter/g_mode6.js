let mode6 = {};
mode6.mousemove  = function(event,ctrl,shift) { };
mode6.mousedown  = function(event,ctrl,shift) { };
mode6.mouseup    = function(event,ctrl,shift) { };
mode6.mouseclick = function(event,ctrl,shift) { };
mode6.dblclick   = function(event,ctrl,shift) { };