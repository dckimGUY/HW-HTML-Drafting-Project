function constructionTuner(keyInfo) {

       if (mode==0) {
windowTuner();
} else if (mode==1) {
grabTuner();
} else if (mode==5) {
edgeTuner();
} else if (mode==6) {
duplicateTuner();
} else if (mode==8) {
tricolourTuner();
} else if (mode==9) {
}

}