function raiseTripartiteZ() {
if (coinFocus!=null) {
       if (coinFocus.dataset.coinTrip==Ts0) {
if (parseInt(coinFocus.style.zIndex) < findZextrema().highestSel0Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) + internalStep + 1; }
} else if (coinFocus.dataset.coinTrip==Ts1) {
if (parseInt(coinFocus.style.zIndex) < findZextrema().highestSel1Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) + internalStep + 1; }
} else if (coinFocus.dataset.coinTrip==Ts2) {
if (parseInt(coinFocus.style.zIndex) < findZextrema().highestSel2Z) { coinFocus.style.zIndex = parseInt(coinFocus.style.zIndex) + internalStep + 1; }
}
}
manageTripartiteZ();
}
