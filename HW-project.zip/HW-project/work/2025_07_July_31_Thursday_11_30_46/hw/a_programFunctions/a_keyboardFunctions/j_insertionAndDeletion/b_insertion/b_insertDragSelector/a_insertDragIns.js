function insertDragIns() {

insertNamedColours();





}
