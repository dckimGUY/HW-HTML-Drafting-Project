function helpMenu(event) {
event.preventDefault();
if (helpMenuOverlay.style.display=="block") { helpMenuOverlay.style.display="none"; } else { helpMenuOverlay.style.display="block"; }
}
