function toggleInterfaceLayer() {
if (interfaceLayer.style.display=="none") {

interfaceLayer.style.display="block";

} else {

interfaceLayer.style.display="none";

}
}
