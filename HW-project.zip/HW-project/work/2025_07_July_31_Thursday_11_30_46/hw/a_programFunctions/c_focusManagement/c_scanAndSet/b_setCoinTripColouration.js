function setCoinTripColouration() {
                    if (coinFocus.dataset.coinTrip==Ts0) {
          coinFocus.firstElementChild.style.color = Fs0;
                     coinFocus.style.outlineColor = Cs0;
coinFocus.firstElementChild.style.backgroundColor = Bs0;
        coinFocus.firstElementChild.style.opacity = Os0;
             } else if (coinFocus.dataset.coinTrip==Ts1) {
          coinFocus.firstElementChild.style.color = Fs1;
                     coinFocus.style.outlineColor = Cs1;
coinFocus.firstElementChild.style.backgroundColor = Bs1;
        coinFocus.firstElementChild.style.opacity = Os1;
             } else if (coinFocus.dataset.coinTrip==Ts2) {
          coinFocus.firstElementChild.style.color = Fs2;
                     coinFocus.style.outlineColor = Cs2;
coinFocus.firstElementChild.style.backgroundColor = Bs2;
        coinFocus.firstElementChild.style.opacity = Os2;
                                                         }
}
