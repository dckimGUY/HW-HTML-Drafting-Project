let mode0 = {};
mode0.mousemove  = function(event,ctrl,shift,M) { };
mode0.mousedown  = function(event,ctrl,shift,M) { };
mode0.mouseup    = function(event,ctrl,shift,M) { };
mode0.mouseclick = function(event,ctrl,shift,M) { };
mode0.dblclick   = function(event,ctrl,shift,M) { };
