let mode2 = {};
mode2.mousemove  = function(event,ctrl,shift,M) { };
mode2.mousedown  = function(event,ctrl,shift,M) { };
mode2.mouseup    = function(event,ctrl,shift,M) { };
mode2.mouseclick = function(event,ctrl,shift,M) { };
mode2.dblclick   = function(event,ctrl,shift,M) { };
