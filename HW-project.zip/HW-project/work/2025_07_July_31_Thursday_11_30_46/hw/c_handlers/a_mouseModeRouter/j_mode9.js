let mode9 = {};
mode9.mousemove  = function(event,ctrl,shift) { };
mode9.mousedown  = function(event,ctrl,shift) { };
mode9.mouseup    = function(event,ctrl,shift) { };
mode9.mouseclick = function(event,ctrl,shift) { };
mode9.dblclick   = function(event,ctrl,shift) { };