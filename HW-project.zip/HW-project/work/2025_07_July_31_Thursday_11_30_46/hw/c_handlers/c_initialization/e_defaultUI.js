const defaultUI = `
<div style="position: absolute; left: 64px; top: 64px;">
<div style="display: flex; justify-content: center;" >
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/a_wizardIcon.png');" onclick="wizarda();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/b_wizardIcon.png');" onclick="wizardb();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/c_wizardIcon.png');" onclick="wizardc();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/d_wizardIcon.png');" onclick="wizardd();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/e_wizardIcon.png');" onclick="wizarde();"></button>
</div>
<div style="display: flex; justify-content: center;" >
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/f_wizardIcon.png');" onclick="wizardf();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/g_wizardIcon.png');" onclick="wizardg();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/h_wizardIcon.png');" onclick="wizardh();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/i_wizardIcon.png');" onclick="wizardi();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/j_wizardIcon.png');" onclick="wizardj();"></button>
</div>
<div style="display: flex; justify-content: center;" >
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/k_wizardIcon.png');" onclick="wizardk();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/l_wizardIcon.png');" onclick="wizardl();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/m_wizardIcon.png');" onclick="wizardm();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/n_wizardIcon.png');" onclick="wizardn();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/o_wizardIcon.png');" onclick="wizardo();"></button>
</div>
<div style="display: flex; justify-content: center;" >
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/p_wizardIcon.png');" onclick="wizardp();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/q_wizardIcon.png');" onclick="wizardq();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/r_wizardIcon.png');" onclick="wizardr();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/s_wizardIcon.png');" onclick="wizards();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/t_wizardIcon.png');" onclick="wizardt();"></button>
</div>
<div style="display: flex; justify-content: center;" >
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/u_wizardIcon.png');" onclick="wizardu();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/v_wizardIcon.png');" onclick="wizardv();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/w_wizardIcon.png');" onclick="wizardw();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/x_wizardIcon.png');" onclick="wizardx();"></button>
<button class="UIwizardButton" style="background-image: URL('./iconSet/wizardIcons/y_wizardIcon.png');" onclick="wizardy();"></button>
</div>
</div>

`;
