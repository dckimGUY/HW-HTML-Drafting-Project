z_wizardCode.u_wizard = {};
z_wizardCode.u_wizard.a_documentation = `

`;
z_wizardCode.u_wizard.b_code = `
Oops! I guess I haven't gotten around to this one yet. Don't worry, I'm working on it!
`;
