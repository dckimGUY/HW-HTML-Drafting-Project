function spaceViewToggle(keyInfo) {
if (spaceView==false) {
spaceViewOn(keyInfo);
} else if (spaceView==true) {
spaceViewOff(keyInfo);
}
}
