function reflowPerTrip(keyInfo) {

const
e      = keyInfo[0],
kC     = keyInfo[1],
cC     = keyInfo[2],
shift  = keyInfo[3],
ctrl   = keyInfo[4],
alt    = keyInfo[5];

reflow(coinTrip.sel0,rev,0);
reflow(coinTrip.sel1,rev,0);
reflow(coinTrip.sel2,rev,0);
if (rev==1) {rev=0;} else {rev=1;};
}
