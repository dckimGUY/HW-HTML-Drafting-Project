function ceilingTripartiteZ() {
if (coinFocus!=null) {
       if (coinFocus.dataset.coinTrip==Ts0) {
if (parseInt(coinFocus.style.zIndex) != findZextrema().highestSel0Z) {
coinFocus.style.zIndex = findZextrema().highestSel0Z + internalStep;
}
} else if (coinFocus.dataset.coinTrip==Ts1) {
if (parseInt(coinFocus.style.zIndex) != findZextrema().highestSel1Z) {
coinFocus.style.zIndex = findZextrema().highestSel1Z + internalStep;
}
} else if (coinFocus.dataset.coinTrip==Ts2) {
if (parseInt(coinFocus.style.zIndex) != findZextrema().highestSel2Z) {
coinFocus.style.zIndex = findZextrema().highestSel2Z + internalStep;
}
}
manageTripartiteZ();
}
}
