let mode5 = {};
mode5.mousemove  = function(event,ctrl,shift) { };
mode5.mousedown  = function(event,ctrl,shift) { };
mode5.mouseup    = function(event,ctrl,shift) { };
mode5.mouseclick = function(event,ctrl,shift) { };
mode5.dblclick   = function(event,ctrl,shift) { };
