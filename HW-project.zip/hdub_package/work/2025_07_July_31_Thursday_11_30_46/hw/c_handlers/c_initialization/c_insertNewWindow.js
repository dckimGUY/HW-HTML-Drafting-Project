function insertNewWindow(keyInfo,refresh) {
const
e      = keyInfo[0],
kC     = keyInfo[1],
cC     = keyInfo[2],
shift  = keyInfo[3],
ctrl   = keyInfo[4],
alt    = keyInfo[5];
const wH = window.innerHeight;
const wW = window.innerwidth;
const fileContentsReference =
`<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<style>
/* html, body           { cursor: none;                                          } */
html, body              { overflow: scroll; scrollbar-width: none;               }
body                    {                         width: 98%; height: 98%;       }
p                       { margin: 0;                                             }
body::-webkit-scrollbar { display: none;                                         }
</style>
<link rel="stylesheet" href="./e_stylesheets/style.css"/>
<title id="documentTitle">emptyFile</title>
</head>
<body>
<div id="utilityLayer0" ></div>
<div id="utilityLayer1" ></div>
<div id="gridLayer"     ></div>
<div id="mouseIconLayer"></div>
<div id="scripts">
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/a_modeRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/b_hjklRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/c_aioNRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/d_numpadRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/e_scrollRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/f_shiftRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/g_topRowRouter.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/a_styleTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/b_borderRadiusTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/c_boxShadowTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/f_paddingTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/g_alignmentTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/h_styleTuner/h_fontTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/a_constructionTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/b_windowTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/c_grabTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/d_edgeTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/e_duplicateTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/a_keyboardRouter/i_constructionTuner/f_tricolourTuner.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/a_spaceViewOn.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/b_spaceViewOff.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/c_spaceViewToggle.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/d_spaceViewToggleAndExposeAttributesAsText.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/e_flipHauptMode.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/f_removePointerEventsNone.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/a_spaceView/g_restorePointerEventsNone.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/b_modeKeys/a_constructionModeKeys.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/b_topModeKeys/b_modeKeys/b_styleDeclarationModeKeys.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/a_gridArray.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/b_pasteOut.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/c_pasteSingle.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/d_pasteMultiple.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/e_groupPaste.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/c_bufferOperations/f_spreadReference.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/a_writeInfoToFace.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/b_togglePartNames.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/c_externalLink.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/d_promptDownloadLink.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/e_promptOutgoingHashLink.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/f_finalizeHTMLandOpen.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/g_wrapParts.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/h_unwrapParts.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/i_findFurthestExtent.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/j_wrapDocument.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/k_findLeastExtent.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/l_wrapDocumentWithScreen.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/m_userSelectNone.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/n_flipAnchorZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/o_buttonDiv.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/p_overflowMain.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/q_makeItContentEditable.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/r_goFullscreen.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/d_miscellaneous/s_setDragPullFromContext.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/a_quitSave.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/b_saveHTMLparticle.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/c_saveParticlePreparation.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/d_copyOpenerContents.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/e_openFile.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/f_appendFile.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/g_openImageFile.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/e_saveAndAppend/h_openHTMLinNewWindow.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/a_flowManagement/a_reflow.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/a_flowManagement/b_reflowGlobal.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/a_flowManagement/c_reflowPerTrip.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/a_globalZManagement/a_manageGlobalZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/a_globalZManagement/b_ceilingGlobalZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/a_globalZManagement/c_lowerGlobalZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/a_globalZManagement/d_raiseGlobalZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/a_globalZManagement/e_floorGlobalZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/b_tripartiteZManagement/a_manageTripartiteZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/b_tripartiteZManagement/b_ceilingTripartiteZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/b_tripartiteZManagement/c_lowerTripartiteZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/b_tripartiteZManagement/d_raiseTripartiteZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/b_tripartiteZManagement/e_floorTripartiteZ.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/f_documentOrder/b_zIndexManagement/c_findZextrema/a_findZextrema.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/a_alignCenter/a_moveLeftAndCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/a_alignCenter/b_moveDownAndCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/a_alignCenter/c_moveUpAndCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/a_alignCenter/d_moveRightAndCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/b_alignEdges/a_moveLeft.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/b_alignEdges/b_moveDown.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/b_alignEdges/c_moveUp.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/b_alignEdges/d_moveRight.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/c_moveAll/a_moveAllLeft.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/c_moveAll/b_moveAllDown.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/c_moveAll/c_moveAllUp.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/c_moveAll/d_moveAllRight.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/g_movement/d_explicitEntry/a_explicitEntryForTopAndLeft.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/h_extendEdge/a_extendEdge.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/h_extendEdge/b_halfSize.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/h_extendEdge/c_doubleSize.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/i_tripartiteOperations/a_assignAllColours.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/i_tripartiteOperations/b_swapColours.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/i_tripartiteOperations/c_setCoinTrip.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/i_tripartiteOperations/d_recoverColouration.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/i_tripartiteOperations/e_readCoins.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/a_deletion/a_deleteCoin.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/a_deletion/b_groupDeletion.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/a_insertNew/a_insertNewCoin.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/a_insertNew/b_insertNewDuplicate.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/a_insertNew/c_insertNewImage.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/a_insertDragIns.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/b_insertNamedColours.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/c_insertGrayscale.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/d_insertFontSizeAndPadding.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/e_insertFontVarious.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/f_insertBorderSelector.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/g_insertBoxShadowSelector.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/h_otherFontAndTemplates.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/b_insertion/b_insertDragSelector/i_insertSingleTemplates.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/c_guideLayer/a_guideLayer.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/j_insertionAndDeletion/c_guideLayer/b_pullFromGuideLayer.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/a_brickHorizontal.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/b_brickVertical.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/c_stackHorizontal.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/d_stackVertical.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/e_stepStackDiagonal.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/f_stackPoint.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/g_stepStackFlat.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/h_stackVerticalCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/k_brickAndStack/i_stackHorizontalCentre.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/a_gridToPadding.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/b_gridToBorderRadius.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/c_gridToFontSize.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/d_gridToOutline.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/e_gridToBoxShadow.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/f_cycleTextAlignment.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/g_cycleFonts.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/l_styleOperations/h_gridToIndent.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/a_enterArticleContent.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/b_enterCODEnote.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/c_enterPHPref.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/d_jsNameAndNote.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/e_enterBackgroundColour.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/f_enterForegroundColour.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/g_enterOutlineColour.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/h_enterPageEchelon.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/i_setSequentialIds.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/m_manualEntry/j_customPrompt.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/n_window/a_windowEdge.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/n_window/b_openTextareaInNewWindow.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/a_innerRotation/a_innerRotation.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/a_innerRotation/b_innerRotationMin.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/a_rotateUnder.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/b_rotateOver.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/c_rotateLeft.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/d_rotateRight.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/e_rotateZleft.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/f_rotateZright.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/b_3dTransform/g_clearRotation.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/c_outerScale/a_outerScaleUp.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/c_outerScale/b_outerScaleDown.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/o_rotationAndScale/c_outerScale/c_resetScale.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/p_F1menu/a_helpMenu.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/q_notificationsSystem/a_noteCoin.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/q_notificationsSystem/b_HJKLnoteCoin.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/q_notificationsSystem/c_noteStyle.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/r_topLayerManager/a_makeTopLayer.js"></script>
<script src="./hw/a_programFunctions/a_keyboardFunctions/r_topLayerManager/b_recoverCoinFocus.js"></script>
<script src="./hw/a_programFunctions/b_mouseFunctions/b_mouseFunctions/a_enterNewPartFromMouseInput.js"></script>
<script src="./hw/a_programFunctions/b_mouseFunctions/b_mouseFunctions/b_mouseGiveFocus.js"></script>
<script src="./hw/a_programFunctions/b_mouseFunctions/b_mouseFunctions/c_mousePlaceCursor.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/a_coinToCursor.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/b_cursorToCoin.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/c_cursorToEnd.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/d_cursorToHome.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/e_coinCentreToCursor.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/f_cursorToCoinCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/g_cursorToCoinTopLeft.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/h_cursorToCoinTopRight.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/i_cursorToCoinBottomLeft.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/j_cursorToCoinBottomRight.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/k_cursorToWindowCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/l_cursorMoveLeft.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/m_cursorMoveRight.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/n_cursorMoveUp.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/o_cursorMoveDown.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/p_cursorToCoinTopCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/q_cursorToCoinLeftCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/r_cursorToCoinRightCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/a_spatialCursor/s_cursorToCoinBottomCentre.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/a_focusFlip.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/b_focusPrevious.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/c_focusNext.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/d_focusFirst.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/e_focusLast.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/f_focusNextColour.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/b_focus/g_focusSet.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/c_scanAndSet/a_scanForCoin.js"></script>
<script src="./hw/a_programFunctions/c_focusManagement/c_scanAndSet/b_setCoinTripColouration.js"></script>
<script src="./hw/b_defaultConfiguration/a_defaultConfig.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/a_mode0.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/b_mode1.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/c_mode2.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/d_mode3.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/e_mode4.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/f_mode5.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/g_mode6.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/h_mode7.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/i_mode8.js"></script>
<script src="./hw/c_handlers/a_mouseModeRouter/j_mode9.js"></script>
<script src="./hw/c_handlers/b_dragAndDrop/a_dragHandler.js"></script>
<script src="./hw/c_handlers/c_initialization/a_namedColourArray.js"></script>
<script src="./hw/c_handlers/c_initialization/b_loadReferenceData.js"></script>
<script src="./hw/c_handlers/c_initialization/c_insertNewWindow.js"></script>
<script src="./hw/c_handlers/c_initialization/d_helpMenu.js"></script>
<script src="./hw/c_handlers/d_mouseHandler/a_handler.js"></script>
<script src="./hw/c_handlers/e_keyboardHandler/a_handler.js"></script>
<script src="./hw/c_handlers/f_boot/a_boot.js"></script>
<script src="./hw/c_handlers/f_boot/b_fMan.js"></script>
<script src="./hw/c_handlers/f_boot/c_setMouseCursorIcon.js"></script>
<script src="./hw/c_handlers/g_copyAndPaste/a_copyAndPasteHandler.js"></script>
<script src="./hw/z_hwObject/a_hwObject.js"></script>
<script src="./hw/z_hwObject/b_hwSpecials.js"></script>
<script src="./hw/c_handlers/c_initialization/c_insertNewWindow.js"></script>
</div>
</body>
</html>
`;let iS = 192;
/*    I    */ if (kC ==  73 && cC ==  73) { window.children[window.children.length] = window.open("","_blank",`height=${window.innerHeight + 1},width=${iS + 1},top=${window.screenTop},left=${window.screenLeft - iS},resizable=yes,noopener=no`); }
/*    O    */ if (kC ==  79 && cC ==  79) { window.children[window.children.length] = window.open("","_blank",`height=${iS + 1},width=${window.innerWidth + 1},top=${window.screenTop + window.innerHeight},left=${window.screenLeft},resizable=yes,noopener=no`); }
/*    A    */ if (kC ==  65 && cC ==  65) { window.children[window.children.length] = window.open("","_blank",`height=${window.innerHeight + 1},width=${iS + 1},top=${window.screenTop},left=${window.screenLeft + window.innerWidth},resizable=yes,noopener=no`); }
/*    i    */ if (kC ==  73 && cC == 105) { window.children[window.children.length] = window.open("","_blank",`height=${window.innerHeight + 1},width=${iS + 1},top=${window.screenTop},left=0,resizable=yes,noopener=no`); }
/*    o    */ if (kC ==  79 && cC == 111) { window.children[window.children.length] = window.open("","_blank",`height=${iS + 1},width=${window.innerWidth + 1},top=${window.screenTop - iS},left=${window.screenLeft},resizable=yes,noopener=no`); }
/*    a    */ if (kC ==  65 && cC ==  97) { window.children[window.children.length] = window.open("","_blank",`height=${window.innerHeight + 1},width=${iS + 1},top=${window.screenTop},left=${screen.width - iS},resizable=yes,noopener=no`); }
/*    n    */ if (kC ==  78 && cC == 110) { window.children[window.children.length] = window.open("","_blank"); }
/* REFRESH */ if (refresh==true)          { window.children[window.children.length] = window.open("","_blank",`height=${window.innerHeight},width=${window.innerWidth},top=${window.screenTop},left=${window.screenLeft},resizable=yes,noopener=no`); window.close(); }
window.children[window.children.length - 1].document.write(fileContentsReference);
try {
for (let j = 0; j < window.parents.length; j++) {
window.parents[j].children[window.parents[j].children.length] = window.children[window.children.length - 1];
}
} catch {}
}
